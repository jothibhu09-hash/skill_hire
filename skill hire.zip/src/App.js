import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Main from './main';
import ChatList from './ChatList';
import ChatPage from './ChatPage';
import LoginPage from './Login';
import CalendarDashboard from './Calender';
import Dashboard from './dashBoard';
import Leaderboard from './LeaderBoard';
function App() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/Main" element={<Main />} />
      <Route path="/ChatList" element={<ChatList />} />
      <Route path="/chat/:id" element={<ChatPage />} />
      <Route path="/calendar" element={<CalendarDashboard />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/Leader" element={<Leaderboard />} />
    </Routes>
  );
}

export default App;
