import React, { useState, useEffect } from 'react';
import './LeaderBoard.css';

// Main App component
export default function Leaderboard() {
  const data = [
    { id: 1, name: 'Alice', score: 120, avatar: 'https://placehold.co/100x100/A3E635/000000?text=A' },
    { id: 2, name: 'Bob', score: 110, avatar: 'https://placehold.co/100x100/FACC15/000000?text=B' },
    { id: 3, name: 'Charlie', score: 100, avatar: 'https://placehold.co/100x100/F472B6/000000?text=C' },
    { id: 4, name: 'David', score: 95, avatar: 'https://placehold.co/100x100/38BDF8/000000?text=D' },
    { id: 5, name: 'Eve', score: 88, avatar: 'https://placehold.co/100x100/EC4899/000000?text=E' },
    { id: 6, name: 'Frank', score: 82, avatar: 'https://placehold.co/100x100/A8A29E/000000?text=F' },
    { id: 7, name: 'Grace', score: 75, avatar: 'https://placehold.co/100x100/818CF8/000000?text=G' },
    { id: 8, name: 'Heidi', score: 60, avatar: 'https://placehold.co/100x100/F9A8D4/000000?text=H' },
  ];

  const topThree = data.slice(0, 3);
  const restOfScores = data.slice(3);

  return (
    <div className="leaderboard-container">
      <div className="leaderboard-card">
        <h1 className="leaderboard-title">
          Awesome Leaderboard
        </h1>
        <p className="leaderboard-subtitle">
          Top 3 and the Rest of the Players
        </p>

        {/* Top 3 Horizontal Section */}
        <div className="top-three-section">
          <h2 className="top-three-title">
            🥇 Top Three 🥈
          </h2>
          <div className="top-three-items">
            {topThree.map((item, index) => (
              <LeaderboardItem
                key={item.id}
                rank={index + 1}
                name={item.name}
                score={item.score}
                avatar={item.avatar}
                isTopThree={true}
              />
            ))}
          </div>
        </div>

        {/* Rest of the Players Vertical Section */}
        <div className="rest-of-players-section">
          <h2 className="rest-of-players-title">
            Rest of the Players
          </h2>
          <ul className="rest-of-players-list">
            {restOfScores.map((item, index) => (
              <LeaderboardItem
                key={item.id}
                rank={index + 4}
                name={item.name}
                score={item.score}
                avatar={item.avatar}
                isTopThree={false}
              />
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

// LeaderboardItem sub-component
function LeaderboardItem({ rank, name, score, avatar, isTopThree }) {
  const [isAnimated, setIsAnimated] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsAnimated(true);
    }, rank * 150);

    return () => clearTimeout(timer);
  }, [rank]);

  const getRankStyle = () => {
    if (isTopThree) {
      switch (rank) {
        case 1:
          return 'first-place';
        case 2:
          return 'second-place';
        case 3:
          return 'third-place';
      }
    }
    return 'default-rank';
  };

  const getCrown = () => {
    if (isTopThree) {
      switch (rank) {
        case 1: return '👑';
        case 2: return '🥈';
        case 3: return '🥉';
      }
    }
    return null;
  };

  return (
    <li
      className={`leaderboard-item ${isTopThree ? 'leaderboard-item-top' : 'leaderboard-item-rest'} ${isAnimated ? 'animated' : ''} ${getRankStyle()}`}
    >
      <div className={`leaderboard-item-content ${isTopThree ? 'flex-col' : 'items-center'}`}>
        <img src={avatar} alt={`${name}'s avatar`} className={`player-avatar ${isTopThree ? 'w-16 h-16 mb-2' : 'w-10 h-10'} border-2 ${rank === 1 ? 'border-yellow-600' : 'border-gray-500'}`} />
        <span className={`player-rank-icon`}>
          {getCrown() || rank}
        </span>
        <span className="player-name">{name}</span>
      </div>
      <div className="player-score">
        {score} <span className="player-score-unit">points</span>
      </div>
    </li>
  );
}