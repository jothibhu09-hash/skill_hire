import React from 'react';
import {
  Box,
  Card,
  CardHeader,
  CardContent,
  CardActions,
  Avatar,
  IconButton,
  Typography,
} from '@mui/material';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined';
import { useNavigate } from 'react-router-dom'


// Simulated PostCard component
function PostCard({ post }) {
  const nav = useNavigate()
  const handleAvatar = () => {
    nav("/dashboard")
  }
  return (
    <Card sx={{ marginBottom: 3 }}>
      {/* Header: Avatar, Username, Time */}
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: '#1976d2' }} onClick={handleAvatar}>
            {post.user[0]} {/* First letter of username */}
          </Avatar>
        }
        title={<Typography variant="subtitle1">{post.user}</Typography>}
        subheader={<Typography variant="caption">{post.time}</Typography>}
      />

      {/* Body: Post Content */}
      <CardContent >
        <Typography variant="body1">{post.content}</Typography>

        {/* Optional post image */}
        {post.image && (
          <Box
            component="img"
            src={post.image}
            alt="Post"
            sx={{
              width: '100%',
              height: 'auto',
              marginTop: 2,
              borderRadius: 2,
            }}
          />
        )}
      </CardContent>

      {/* Footer: Like, Comment, Share buttons */}
      <CardActions disableSpacing>
        <IconButton>
          <FavoriteBorderIcon />
        </IconButton>
        <IconButton>
          <ChatBubbleOutlineIcon />
        </IconButton>
        <IconButton>
          <ShareOutlinedIcon />
        </IconButton>
      </CardActions>
    </Card>
  );
}

// Sample data
const samplePosts = [
  {
    id: 1,
    user: 'John Doe',
    time: '2 hours ago',
    content: 'Hello, this is my first post!',
    image: 'https://via.placeholder.com/600x300', // Example image URL
  },
  {
    id: 2,
    user: 'Jane Smith',
    time: '1 hour ago',
    content: 'React is awesome! 😍',
  },
  {
    id: 3,
    user: 'Michael Lee',
    time: '30 minutes ago',
    content: 'Just deployed my first app!',
    image: 'https://via.placeholder.com/600x300',
  },
];

function PostFeed() {
  return (
    <Box sx={{ padding: 2, maxWidth: 600, margin: '0 auto' }}>
      {samplePosts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </Box>
  );
}

export default PostFeed;
