import React, { useState } from 'react';
import {
    AppBar,
    Toolbar,
    Typography,
    IconButton,
    Drawer,
    Box,
    Avatar,
    Divider,
    InputBase,
    Paper,
} from '@mui/material';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import MessageIcon from '@mui/icons-material/Message';
import { useNavigate } from 'react-router-dom'
import PostFeed from './postfeed';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents'; // Trophy
import CalendarTodayIcon from '@mui/icons-material/CalendarToday'; // Calendar
import  './dashBoard.css';
function Main() {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const nav = useNavigate()
    const toggleDrawer = (open) => () => {
        setIsSidebarOpen(open);
    };
    const handlemessage = () => {
        nav("/ChatList")
    }
    const handlecalender = () => {
        nav("/calendar")
    }
    const handleprofile = () => {
        nav("/Dashboard")
    }
    const handleTrophy = () => {
        nav("/Leader")
    }
    return (
        <Box
            sx={{
                minHeight: '100vh',
                backgroundColor: '#f0f2f5',
                backgroundImage: `url('/background.jpg')`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
            }}
        >
            {/* App Bar */}
            <AppBar position="static">
                <Toolbar sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="h6" sx={{ mr: 2 }}>
                        SKILL HIRE
                    </Typography>

                    <Paper
                        component="form"
                        sx={{
                            display: 'flex',
                            alignItems: 'center',
                            width: 300,
                            px: 2,
                            py: 0.5,
                            borderRadius: 4,
                            backgroundColor: 'white',
                        }}
                        elevation={0}
                    >
                        <InputBase
                            placeholder="Search…"
                            inputProps={{ 'aria-label': 'search' }}
                            sx={{ flex: 1 }}
                        />
                    </Paper>
                    <Typography variant="h6" sx={{ mr: 2 }}>
                        notification
                    </Typography>

                    <Box>
                        <IconButton color="inherit" onClick={toggleDrawer(true)} sx={{ ml: 2 }}>
                            <AccountCircleIcon />
                        </IconButton>

                        <IconButton
                            color="inherit"
                            onClick={handlemessage} // <- Open ChatList
                            sx={{ ml: 1 }}
                        >
                            <MessageIcon />
                        </IconButton>

                        <IconButton
                            color="inherit"
                            onClick={handleTrophy} // <- Open ChatList
                            sx={{ ml: 1 }}
                        >
                            <EmojiEventsIcon />
                        </IconButton>
                        <IconButton
                            color="inherit"
                            onClick={handlecalender} // <- Open ChatList
                            sx={{ ml: 1 }}
                        >
                            {/* Trophy icon */}
                            <CalendarTodayIcon />  {/* Calendar icon */}

                        </IconButton>

                    </Box>
                </Toolbar>
            </AppBar>

            {/* Sidebar */}
            <Drawer anchor="right" open={isSidebarOpen} onClose={toggleDrawer(false)}>
                <Box
                    sx={{ width: 250, padding: 2 }}
                    role="presentation"
                    onClick={toggleDrawer(false)}
                    onKeyDown={toggleDrawer(false)}
                >
                    <Box display="flex" flexDirection="column" alignItems="center">
                        <Avatar sx={{ width: 80, height: 80, mb: 2 }} />
                        <Typography variant="h6" onClick={handleprofile}>Admin</Typography>
                        <Typography variant="body2" color="text.secondary">
                            admin@example.com
                        </Typography>
                    </Box>
                    <Divider sx={{ my: 2 }} />
                    <Typography variant="body1">Settings</Typography>
                    <Typography variant="body1">Logout</Typography>
                </Box>
            </Drawer>

            {/* Main Content Switch */}

            <PostFeed />

        </Box>
    );
}

export default Main;

